## [1.0.2](https://github.com/calgiellc/quran-npm/compare/v1.0.1...v1.0.2) (2026-01-06)

### Bug Fixes

- disable duplicate release workflow and semantic-release npm publishing for manual control ([87e305e](https://github.com/calgiellc/quran-npm/commit/87e305ee8bd5db8662b2bf04d876562ef050fe36))

## [1.0.1](https://github.com/calgiellc/quran-npm/compare/v1.0.0...v1.0.1) (2026-01-06)

### Bug Fixes

- build error VI ([1bbc14f](https://github.com/calgiellc/quran-npm/commit/1bbc14fa3a35053404d3777cd8047b005b4af267))

# 1.0.0 (2026-01-06)

### Bug Fixes

- build error ([e47aa7e](https://github.com/calgiellc/quran-npm/commit/e47aa7e4d0710bb45b159ad951db5488d895049d))
- build error II ([b1953b8](https://github.com/calgiellc/quran-npm/commit/b1953b8f6922b9be84f71663940b050885bc86f2))
- build error III ([58368d8](https://github.com/calgiellc/quran-npm/commit/58368d8245d3fc1c83cb1b4df52cbaa1f5894ced))
- build error IIV ([e440db8](https://github.com/calgiellc/quran-npm/commit/e440db848c1591716ce5b20de0e5ec48ce8d146b))
- build error IV ([8819f36](https://github.com/calgiellc/quran-npm/commit/8819f3692e21698ac14d2271d15448d2766dec22))
- build error V ([47ab814](https://github.com/calgiellc/quran-npm/commit/47ab81425c89c79f71bb3e4514e18ed6fad8186a))
- deployment' ([fdf7753](https://github.com/calgiellc/quran-npm/commit/fdf77536f1e7e6b24ab6bc80fcb1fd0413ddbf10))
- remove Node.js fs/path imports for React Native compatibility ([35f5cbc](https://github.com/calgiellc/quran-npm/commit/35f5cbce509aa8cab5d971d024922050b259ea92))
- update semantic-release workflow permissions ([cef94ae](https://github.com/calgiellc/quran-npm/commit/cef94ae974a4a70e911aeb357fc8f85fdbb6ef17))

## [1.2.1](https://github.com/calgiellc/azan-npm/compare/v1.2.0...v1.2.1) (2026-01-05)

### Bug Fixes

- use timezone-aware date calculation for Hijri date ([ec099ef](https://github.com/calgiellc/azan-npm/commit/ec099ef24653d8ff5fd90c09f84bc512e5f1ff12))

# [1.2.0](https://github.com/calgiellc/azan-npm/compare/v1.1.1...v1.2.0) (2026-01-05)

### Features

- add hijriDateAdjustment option for local moon sighting alignment ([908872f](https://github.com/calgiellc/azan-npm/commit/908872f8baa73a1be052c4f3cb3f05cf17e6351d))

## [1.1.1](https://github.com/calgiellc/azan-npm/compare/v1.1.0...v1.1.1) (2026-01-05)

### Bug Fixes

- adjust Hijri date calculation for Islamic day starting at sunset ([74f3f43](https://github.com/calgiellc/azan-npm/commit/74f3f432a7245b3c48aad74b97f592bdb2a2965a))

# [1.1.0](https://github.com/calgiellc/azan-npm/compare/v1.0.7...v1.1.0) (2026-01-05)

### Features

- add getFormattedPrayerTimes method to AzanApp ([c962408](https://github.com/calgiellc/azan-npm/commit/c962408e84fc69d7fd959f2a41ad1005bfe65e3a))

## [1.0.7](https://github.com/calgiellc/azan-npm/compare/v1.0.6...v1.0.7) (2026-01-05)

### Bug Fixes

- prevent Web Worker code execution in React Native/Expo ([f7ebaca](https://github.com/calgiellc/azan-npm/commit/f7ebaca853461e3a3c3cc6b1e6b8294c9571bfa5))

## [1.0.6](https://github.com/calgiellc/azan-npm/compare/v1.0.5...v1.0.6) (2026-01-05)

### Bug Fixes

- prevent moment-timezone require() in React Native/Expo ([0d2dcf7](https://github.com/calgiellc/azan-npm/commit/0d2dcf7600e4dc87b2d204909152ceb6fafb94cf))

## [1.0.5](https://github.com/calgiellc/azan-npm/compare/v1.0.4...v1.0.5) (2026-01-05)

### Bug Fixes

- correct ESM module path in package.json exports ([1012af6](https://github.com/calgiellc/azan-npm/commit/1012af6ddcc676d02ea177a5e83b55b5dbb17dcb))

## [1.0.4](https://github.com/calgiellc/azan-npm/compare/v1.0.3...v1.0.4) (2026-01-05)

### Bug Fixes

- exclude docs and examples from npm package ([b52970d](https://github.com/calgiellc/azan-npm/commit/b52970de8abd466da14e602f5dd1287a986b9137))
