/**
 * Base error class for all Quran library errors
 */
export declare class QuranError extends Error {
    readonly code: string;
    readonly data?: unknown | undefined;
    constructor(message: string, code: string, data?: unknown | undefined);
}
/**
 * Error codes used throughout the library
 */
export declare enum QuranErrorCode {
    /** Invalid surah number (must be 1-114) */
    INVALID_SURAH_NUMBER = "INVALID_SURAH_NUMBER",
    /** Invalid ayah number */
    INVALID_AYAH_NUMBER = "INVALID_AYAH_NUMBER",
    /** Reciter not found */
    RECITER_NOT_FOUND = "RECITER_NOT_FOUND",
    /** Audio URL not found for the specified reciter/surah/ayah */
    AUDIO_URL_NOT_FOUND = "AUDIO_URL_NOT_FOUND",
    /** Error loading data files */
    DATA_LOAD_ERROR = "DATA_LOAD_ERROR",
    /** Data validation failed */
    DATA_VALIDATION_ERROR = "DATA_VALIDATION_ERROR",
    /** Search query is invalid */
    INVALID_SEARCH_QUERY = "INVALID_SEARCH_QUERY"
}
/**
 * Creates an error for invalid surah number
 */
export declare function createInvalidSurahNumberError(surahNumber: number): QuranError;
/**
 * Creates an error for invalid ayah number
 */
export declare function createInvalidAyahNumberError(surahNumber: number, ayahNumber: number, maxAyahs: number): QuranError;
/**
 * Creates an error for reciter not found
 */
export declare function createReciterNotFoundError(reciterId: string): QuranError;
/**
 * Creates an error for audio URL not found
 */
export declare function createAudioUrlNotFoundError(reciterId: string, surahNumber: number, ayahNumber?: number): QuranError;
/**
 * Creates an error for data loading failures
 */
export declare function createDataLoadError(resource: string, originalError?: Error): QuranError;
/**
 * Creates an error for data validation failures
 */
export declare function createDataValidationError(message: string, data?: unknown): QuranError;
//# sourceMappingURL=errors.d.ts.map