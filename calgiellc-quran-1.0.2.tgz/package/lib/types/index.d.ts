export { Quran, createQuran, createQuranWithReciter, createQuranSession, } from './quran-factory';
export { QuranSession } from './core/quran-session';
export { ReciterManager } from './core/reciter-manager';
export { AudioManager } from './core/audio-manager';
export type { Ayah, Surah, Reciter, AudioUrl, FilterOptions, PaginationOptions, PaginatedResult, SearchOptions, SearchResult, QuranMetadata, } from './types';
export { QuranError, QuranErrorCode, createInvalidSurahNumberError, createInvalidAyahNumberError, createReciterNotFoundError, createAudioUrlNotFoundError, createDataLoadError, createDataValidationError, } from './errors';
export { validateSurahNumber, validateAyahNumber } from './utils/validation';
//# sourceMappingURL=index.d.ts.map