export type { Ayah, Surah, Reciter, AudioUrl, FilterOptions, PaginationOptions, PaginatedResult, SearchOptions, SearchResult, QuranMetadata, } from './quran';
//# sourceMappingURL=index.d.ts.map