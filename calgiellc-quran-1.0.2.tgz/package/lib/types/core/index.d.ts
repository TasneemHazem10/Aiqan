export { Quran } from './quran';
export { ReciterManager } from './reciter-manager';
export { AudioManager } from './audio-manager';
//# sourceMappingURL=index.d.ts.map