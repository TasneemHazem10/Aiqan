import { AudioUrl, Reciter } from '../types';
/**
 * Manages audio URL generation and retrieval
 */
export declare class AudioManager {
    /**
     * Generate audio URL for a specific ayah
     * For mp3quran.net format: baseurl/Language/reciter-name/surah-number
     * For legacy format: baseurl/{surahNumber:03d}{ayahNumber:03d}.{format}
     */
    static generateAudioUrl(reciter: Reciter, surahNumber: number, ayahNumber: number): string;
    /**
     * Generate all audio URLs for a surah
     */
    static generateSurahAudioUrls(reciter: Reciter, surahNumber: number, numberOfAyahs: number): AudioUrl[];
    /**
     * Generate audio URL pattern for a reciter
     * Useful for understanding the URL structure
     */
    static getAudioUrlPattern(reciter: Reciter): string;
}
//# sourceMappingURL=audio-manager.d.ts.map