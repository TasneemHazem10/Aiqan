import { Reciter } from '../types';
/**
 * Manages reciter data and operations
 */
export declare class ReciterManager {
    private reciters;
    private recitersBySurah;
    /**
     * Initialize the reciter manager with reciter data
     */
    constructor(reciters?: Reciter[]);
    /**
     * Load reciters into the manager
     */
    private loadReciters;
    /**
     * Get all reciters
     */
    getAllReciters(): Reciter[];
    /**
     * Get a reciter by ID
     */
    getReciter(reciterId: string): Reciter | null;
    /**
     * Check if a reciter exists
     */
    hasReciter(reciterId: string): boolean;
    /**
     * Get all reciters that have recorded a specific surah
     */
    getRecitersBySurah(surahNumber: number): Reciter[];
    /**
     * Check if a reciter has recorded a specific surah
     */
    hasSurah(reciterId: string, surahNumber: number): boolean;
    /**
     * Get surah numbers available for a specific reciter
     */
    getSurahNumbers(reciterId: string): number[];
    /**
     * Update reciters (useful for dynamic loading)
     */
    updateReciters(reciters: Reciter[]): void;
}
//# sourceMappingURL=reciter-manager.d.ts.map