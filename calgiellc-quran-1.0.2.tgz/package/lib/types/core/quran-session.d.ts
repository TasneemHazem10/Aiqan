import { Quran } from './quran';
import { Surah, Reciter } from '../types';
/**
 * A simplified session API for working with a specific reciter
 * This provides an intuitive, developer-friendly interface for the common workflow:
 * 1. User picks a reciter
 * 2. Get surahs for that reciter
 * 3. Play surah audio and read full text
 */
export declare class QuranSession {
    private quran;
    private reciterId;
    constructor(quran: Quran, reciterId: string);
    /**
     * Get the reciter for this session
     */
    get reciter(): Reciter;
    /**
     * Get all surahs available for this reciter
     * This is the main list users will see
     */
    get surahs(): Surah[];
    /**
     * Get a specific surah by number
     */
    getSurah(surahNumber: number): Surah | null;
    /**
     * Get audio URL for a surah
     * Perfect for mp3 players
     */
    getAudioUrl(surahNumber: number): string | null;
    /**
     * Get full text of a surah
     * Perfect for displaying while audio plays
     */
    getFullText(surahNumber: number): string | null;
    /**
     * Get everything needed to play a surah
     * Returns audio URL and full text in one call
     */
    getPlayerData(surahNumber: number): {
        audioUrl: string | null;
        fullText: string | null;
        surah: Surah | null;
    };
    /**
     * Check if a surah is available for this reciter
     */
    hasSurah(surahNumber: number): boolean;
    /**
     * Get the number of surahs available for this reciter
     */
    get surahCount(): number;
}
//# sourceMappingURL=quran-session.d.ts.map