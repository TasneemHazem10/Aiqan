import { Surah, Ayah, Reciter, AudioUrl, SearchOptions, SearchResult, FilterOptions, PaginationOptions, PaginatedResult, QuranMetadata } from '../types';
import type { QuranSession } from './quran-session';
/**
 * Main Quran class providing access to Quran text and audio data
 */
export declare class Quran {
    private surahs;
    private reciterManager;
    private filteredSurahsCache;
    private allSurahsCache;
    private preferredReciterId;
    /**
     * Create a new Quran instance
     * @param surahs - Array of surahs to load
     * @param reciters - Array of reciters to load
     * @param preferredReciterId - Optional preferred reciter ID to set on initialization
     */
    constructor(surahs?: Surah[], reciters?: Reciter[], preferredReciterId?: string);
    /**
     * Load surahs into the Quran instance
     */
    private loadSurahs;
    /**
     * Get all surahs
     * Results are cached for performance
     *
     * @returns Array of all surahs sorted by number
     * @example
     * ```typescript
     * const quran = createQuran();
     * const surahs = quran.getAllSurahs();
     * console.log(`Total surahs: ${surahs.length}`); // 114
     * ```
     */
    getAllSurahs(): Surah[];
    /**
     * Generate cache key from filter options
     */
    private getFilterCacheKey;
    /**
     * Get surahs with optional filters
     * Results are cached for performance
     */
    getSurahs(filters?: FilterOptions): Surah[];
    /**
     * Get paginated surahs with optional filters
     */
    getSurahsPaginated(pagination?: PaginationOptions, filters?: FilterOptions): PaginatedResult<Surah>;
    /**
     * Get paginated search results
     */
    searchPaginated(query: string, pagination?: PaginationOptions, options?: Omit<SearchOptions, 'limit'>): PaginatedResult<SearchResult>;
    /**
     * Get a surah by number
     */
    getSurah(surahNumber: number): Surah | null;
    /**
     * Get an ayah by surah and ayah number
     */
    getAyah(surahNumber: number, ayahNumber: number): Ayah | null;
    /**
     * Get all reciters
     */
    getAllReciters(): Reciter[];
    /**
     * Get a reciter by ID
     */
    getReciter(reciterId: string): Reciter | null;
    /**
     * Get surahs available for a specific reciter
     */
    getSurahsByReciter(reciterId: string): Surah[];
    /**
     * Get audio URL for a specific ayah
     */
    getAudioUrl(reciterId: string, surahNumber: number, ayahNumber: number): string | null;
    /**
     * Get all audio URLs for a surah
     */
    getSurahAudioUrls(reciterId: string, surahNumber: number): AudioUrl[];
    /**
     * Search the Quran text
     * This is a basic implementation - can be enhanced later
     */
    search(query: string, options?: SearchOptions): SearchResult[];
    /**
     * Update surahs (useful for dynamic loading)
     */
    updateSurahs(surahs: Surah[]): void;
    /**
     * Update reciters (useful for dynamic loading)
     */
    updateReciters(reciters: Reciter[]): void;
    /**
     * Get metadata about the Quran data
     *
     * @returns Metadata including version, last updated, and counts
     * @example
     * ```typescript
     * const quran = createQuran();
     * const metadata = quran.getMetadata();
     * console.log(`Total surahs: ${metadata.totalSurahs}`);
     * console.log(`Total ayahs: ${metadata.totalAyahs}`);
     * ```
     */
    getMetadata(): QuranMetadata;
    /**
     * Get total number of surahs
     *
     * @returns Total number of surahs (should be 114)
     * @example
     * ```typescript
     * const count = quran.getSurahCount();
     * console.log(count); // 114
     * ```
     */
    getSurahCount(): number;
    /**
     * Get total number of ayahs in a surah
     *
     * @param surahNumber - Surah number (1-114)
     * @returns Number of ayahs in the surah, or 0 if surah not found
     * @example
     * ```typescript
     * const ayahCount = quran.getAyahCount(1);
     * console.log(ayahCount); // 7
     * ```
     */
    getAyahCount(surahNumber: number): number;
    /**
     * Get total number of reciters
     *
     * @returns Total number of available reciters
     * @example
     * ```typescript
     * const reciterCount = quran.getReciterCount();
     * console.log(reciterCount); // 10
     * ```
     */
    getReciterCount(): number;
    /**
     * Set the preferred reciter
     * This will be used for convenience methods that don't require specifying a reciter
     *
     * @param reciterId - The ID of the reciter to set as preferred
     * @throws {QuranError} If reciter is not found
     * @example
     * ```typescript
     * const quran = createQuran();
     * quran.setPreferredReciter('alzain');
     * const surahs = quran.getPreferredReciterSurahs();
     * ```
     */
    setPreferredReciter(reciterId: string): void;
    /**
     * Get the preferred reciter
     *
     * @returns The preferred reciter, or null if none is set
     * @example
     * ```typescript
     * const reciter = quran.getPreferredReciter();
     * if (reciter) {
     *   console.log(`Preferred reciter: ${reciter.name}`);
     * }
     * ```
     */
    getPreferredReciter(): Reciter | null;
    /**
     * Get the preferred reciter ID
     *
     * @returns The preferred reciter ID, or null if none is set
     */
    getPreferredReciterId(): string | null;
    /**
     * Clear the preferred reciter
     *
     * @example
     * ```typescript
     * quran.clearPreferredReciter();
     * ```
     */
    clearPreferredReciter(): void;
    /**
     * Get surahs available for the preferred reciter
     *
     * @returns Array of surahs available for the preferred reciter
     * @throws {QuranError} If no preferred reciter is set
     * @example
     * ```typescript
     * quran.setPreferredReciter('alzain');
     * const surahs = quran.getPreferredReciterSurahs();
     * ```
     */
    getPreferredReciterSurahs(): Surah[];
    /**
     * Get audio URL for a surah using the preferred reciter
     * This is useful for mp3 players that play the entire surah
     *
     * @param surahNumber - Surah number (1-114)
     * @returns Audio URL for the surah, or null if not available
     * @throws {QuranError} If no preferred reciter is set
     * @example
     * ```typescript
     * quran.setPreferredReciter('alzain');
     * const audioUrl = quran.getSurahAudioUrl(1);
     * // Use in audio player: <audio src={audioUrl} />
     * ```
     */
    getSurahAudioUrl(surahNumber: number): string | null;
    /**
     * Get audio URL for a surah for a specific reciter
     * This is useful for mp3 players that play the entire surah
     *
     * @param reciterId - Reciter ID
     * @param surahNumber - Surah number (1-114)
     * @returns Audio URL for the surah, or null if not available
     * @example
     * ```typescript
     * const audioUrl = quran.getSurahAudioUrlForReciter('alzain', 1);
     * // Returns: "https://www.mp3quran.net/eng/alzain/1"
     * ```
     */
    getSurahAudioUrlForReciter(reciterId: string, surahNumber: number): string | null;
    /**
     * Get full text of a surah
     * Returns the fullText field if available, otherwise combines all ayahs
     *
     * @param surahNumber - Surah number (1-114)
     * @returns Full text of the surah with ayah separators, or null if surah not found
     * @example
     * ```typescript
     * const fullText = quran.getSurahFullText(1);
     * // Returns: "بِسْمِ اللَّهِ... [1] الْحَمْدُ لِلَّهِ... [2] ..."
     * ```
     */
    getSurahFullText(surahNumber: number): string | null;
    /**
     * Create a simplified session for working with a specific reciter
     * This provides an intuitive, developer-friendly API
     *
     * @param reciterId - The ID of the reciter to create a session for
     * @returns A QuranSession instance with simplified API
     * @example
     * ```typescript
     * const quran = createQuran();
     * const session = quran.withReciter('alzain');
     *
     * // Get all surahs for this reciter
     * const surahs = session.surahs;
     *
     * // Get everything needed to play a surah
     * const { audioUrl, fullText, surah } = session.getPlayerData(1);
     * ```
     */
    withReciter(reciterId: string): QuranSession;
}
//# sourceMappingURL=quran.d.ts.map