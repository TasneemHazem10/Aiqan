import { Surah, Reciter, QuranMetadata } from '../types';
/**
 * Structure of the Quran data file
 */
interface QuranDataFile {
    metadata: QuranMetadata;
    surahs: Surah[];
}
/**
 * Structure of the reciters data file
 */
interface RecitersDataFile {
    reciters: Reciter[];
}
/**
 * Loads and validates Quran data from JSON
 * Data is imported directly and bundled, making it work in all environments
 */
export declare function loadQuranData(): Promise<QuranDataFile>;
/**
 * Loads and validates reciters data from JSON
 * Data is imported directly and bundled, making it work in all environments
 */
export declare function loadRecitersData(): Promise<RecitersDataFile>;
/**
 * Synchronous version of loadQuranData for cases where data is already loaded
 * Data is imported directly and bundled, making it work in all environments
 */
export declare function loadQuranDataSync(): QuranDataFile;
/**
 * Synchronous version of loadRecitersData for cases where data is already loaded
 * Data is imported directly and bundled, making it work in all environments
 */
export declare function loadRecitersDataSync(): RecitersDataFile;
export {};
//# sourceMappingURL=data-loader.d.ts.map