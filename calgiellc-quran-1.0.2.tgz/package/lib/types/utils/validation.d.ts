import { Surah, Reciter, Ayah } from '../types';
/**
 * Validates that a surah number is within valid range (1-114)
 */
export declare function validateSurahNumber(surahNumber: number): void;
/**
 * Validates that an ayah number is valid for a given surah
 */
export declare function validateAyahNumber(surahNumber: number, ayahNumber: number, maxAyahs: number): void;
/**
 * Validates a surah object structure
 */
export declare function validateSurah(surah: unknown): surah is Surah;
/**
 * Validates an ayah object structure
 */
export declare function validateAyah(ayah: unknown, surahNumber: number, expectedNumber: number): ayah is Ayah;
/**
 * Validates a reciter object structure
 */
export declare function validateReciter(reciter: unknown): reciter is Reciter;
//# sourceMappingURL=validation.d.ts.map