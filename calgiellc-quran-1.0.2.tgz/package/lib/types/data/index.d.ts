/**
 * Data directory exports
 * This file will be used to export data when it's ready to be embedded
 */
export declare const quranData: {
    metadata: {
        version: string;
        lastUpdated: string;
        totalSurahs: number;
        totalAyahs: number;
    };
    surahs: never[];
};
export declare const recitersData: {
    reciters: never[];
};
//# sourceMappingURL=index.d.ts.map