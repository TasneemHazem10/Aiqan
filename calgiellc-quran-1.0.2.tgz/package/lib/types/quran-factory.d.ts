import { Quran } from './core/quran';
import { QuranSession } from './core/quran-session';
import { Surah, Reciter } from './types';
/**
 * Factory function to create a Quran instance
 * This is the recommended way to create a Quran instance
 */
export declare function createQuran(): Quran;
/**
 * Create a Quran instance with a preferred reciter
 * This is useful when you want to initialize with a user's preferred reciter
 *
 * @param reciterId - The ID of the preferred reciter
 * @returns Quran instance with preferred reciter set
 * @throws {QuranError} If reciter is not found
 * @example
 * ```typescript
 * // User selects a reciter
 * const reciters = quran.getAllReciters();
 * const userReciter = reciters[0];
 *
 * // Initialize with preferred reciter
 * const quran = createQuranWithReciter(userReciter.id);
 *
 * // Get surahs for this reciter
 * const surahs = quran.getPreferredReciterSurahs();
 * ```
 */
export declare function createQuranWithReciter(reciterId: string): Quran;
/**
 * Create a simplified Quran session for a specific reciter
 * This is the easiest way to work with a reciter - perfect for the common workflow
 *
 * @param reciterId - The ID of the reciter
 * @returns QuranSession with simplified API
 * @throws {Error} If reciter is not found
 * @example
 * ```typescript
 * // Simple 3-step workflow:
 * // 1. Get all reciters and let user pick
 * const quran = createQuran();
 * const reciters = quran.getAllReciters();
 *
 * // 2. Create session with user's picked reciter
 * const session = createQuranSession(reciters[0].id);
 *
 * // 3. Get surahs and play!
 * const surahs = session.surahs; // All surahs for this reciter
 * const { audioUrl, fullText } = session.getPlayerData(1); // Everything to play surah 1
 * ```
 */
export declare function createQuranSession(reciterId: string): QuranSession;
/**
 * Create a Quran instance with custom data
 * Useful for testing or when loading data from external sources
 */
export declare function createQuranWithData(surahs: Surah[], reciters?: Reciter[], preferredReciterId?: string): Quran;
export { Quran };
//# sourceMappingURL=quran-factory.d.ts.map