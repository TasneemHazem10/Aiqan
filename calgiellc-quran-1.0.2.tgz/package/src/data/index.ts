/**
 * Data directory exports
 * This file will be used to export data when it's ready to be embedded
 */

// Placeholder - will be populated when data is collected
export const quranData = {
  metadata: {
    version: '1.0.0',
    lastUpdated: new Date().toISOString(),
    totalSurahs: 114,
    totalAyahs: 6236,
  },
  surahs: [],
};

export const recitersData = {
  reciters: [],
};
